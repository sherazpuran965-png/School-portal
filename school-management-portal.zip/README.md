# School Management Portal

A multi-portal school management app (Administration, Teachers, Students, Fees, Expenses) built with React + Vite. Supports English, Urdu, and Arabic (with RTL layout).

## Local setup (pehle apne computer par chalayein)

Requirements: [Node.js](https://nodejs.org) (v18 ya usse upar) installed hona chahiye.

```bash
npm install
npm run dev
```

Browser mein `http://localhost:5173` khol lein — app live dikhega.

## Build (production ke liye)

```bash
npm run build
```

Ye `dist/` folder banayega jo deploy karne ke liye ready hoga.

## GitHub par upload karna

```bash
git init
git add .
git commit -m "Initial commit: school management portal"
git branch -M main
git remote add origin https://github.com/<your-username>/school-management-portal.git
git push -u origin main
```

## Deploy — Option A: GitHub Pages

1. `vite.config.js` mein `base: "/school-management-portal/"` already set hai — agar aap ne repo ka naam kuch aur rakha hai to yahan wo naam likhein (slashes ke sath).
2. Ye command chalayein:
   ```bash
   npm run deploy
   ```
   (Ye `gh-pages` package se `dist/` folder ko `gh-pages` branch par push kar dega.)
3. GitHub repo → **Settings** → **Pages** mein jaa kar source branch `gh-pages` select karein.
4. Kuch minute baad app `https://<your-username>.github.io/school-management-portal/` par live ho jayega.

## Deploy — Option B: Vercel (aasan tareeka)

1. [vercel.com](https://vercel.com) par GitHub account se login karein.
2. **"Add New Project"** → apna GitHub repo select karein.
3. Framework automatically "Vite" detect ho jayega — bas **"Deploy"** dabayein.
4. Kuch second mein live link mil jayega, aur har naye `git push` par automatically update hota rahega.

## Project structure

```
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx      # React entry point
    └── App.jsx       # The full school portal (all logic + UI)
```

## Notes

- Sab data (students, teachers, fees, expenses) abhi sirf browser memory mein hai — page reload karne par reset ho jayega. Agar data permanently save karna ho (database ke sath), wo agla step hoga.
- Photos upload karne ke liye camera/gallery access browser khud manage karta hai — koi extra setup nahi chahiye.
