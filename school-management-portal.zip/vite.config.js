import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// If deploying to GitHub Pages as a PROJECT site (https://username.github.io/repo-name/),
// set base to "/repo-name/". If deploying to Vercel/Netlify, or a GitHub Pages USER site
// (username.github.io), leave base as "/".
export default defineConfig({
  plugins: [react()],
  base: "/school-management-portal/",
});
