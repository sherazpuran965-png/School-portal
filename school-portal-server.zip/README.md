# School Portal - Server version

## Chalane ka tareeqa (school ke computer par)
1. Node.js 22.13 ya upar install karein (https://nodejs.org). Koi `npm install` nahi chahiye.
2. Is folder mein terminal kholein aur chalayein:

       node server.js

3. Pehli dafa screen par admin ka password likha aata hai ("FIRST RUN - login: admin / ...").
   Isay copy karein, browser mein http://localhost:3000 kholein, login karein, phir foran
   upar "Password" button se badal dein.
4. Same WiFi ke dusre phone/computer se: http://<is computer ka IP>:3000

## Internet par chalana (walid bhi dekh sakein)
Aap ko ek chhota server (VPS, Ubuntu) chahiye jis par Node 22 ho, aur ek domain.
HTTPS ke baghair isay internet par KABHI na chalayein. Sab se aasan: Caddy (khud HTTPS laga deta hai).

Caddyfile:

    school.example.com {
        reverse_proxy localhost:3000
    }

Server ko hamesha chalta rakhne ke liye systemd service ya `pm2` istemal karein.
Environment: PORT (default 3000), DATA_DIR (default ./data), TZ (default Asia/Karachi).

## Data aur backup
- Data `data/school.db` mein hai. Server rozana `data/backups/` mein copy banata hai (aakhri 14 din).
- Admin "Users & Backup" se JSON backup download kar sakta hai. Usi file se restore ho jata hai.
- `data/` folder ko kisi aur jagah (USB, Drive) bhi copy karte rahein.

## Purana (offline HTML) data lana
Purani HTML mein "Users & Backup" > "Download backup". Phir is server mein admin login se
"Users & Backup" > "Restore" se wohi file chunein. Users (login) restore se nahi badalte,
naye users yahin banayein.

## Naya (marhala 2)
- Dashboard (admin aur accountant): students, aaj ki hazri, fees baqaya, wasooli, kharche, bachat, 6 mahine ka graph, sab se zyada baqaya.
- Vouchers: mahine ka fee voucher har student ka, class ke hisab se, print ya WhatsApp.

## Security
- Passwords server par hash hote hain. 5 galat koshishon ke baad 10 minute ka lockout.
- Har tabdeeli "Audit log" mein likhi jati hai (kisne, kab, kya).
- Teacher/accountant sirf apne hisse ke routes istemal kar sakte hain (server rokta hai).
