// School Portal - server. Needs Node.js 22.13+ (no npm install). Run: node server.js
process.env.TZ=process.env.TZ||'Asia/Karachi';
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
const PORT=+process.env.PORT||3000,DATA=process.env.DATA_DIR||path.join(__dirname,'data'),BK=path.join(DATA,'backups');
fs.mkdirSync(BK,{recursive:true});
const db=new DatabaseSync(path.join(DATA,'school.db'));
db.exec('create table if not exists kv(k text primary key,v text);create table if not exists audit(id integer primary key,t text,u text,a text,d text)');
const COLS={users:[],students:[],payments:[],att:{},teachers:[],tpay:[],exams:[],marks:{},exp:[],notices:[],tt:[],tatt:{},settings:{},hifz:[],para:{},don:[],books:[],loans:[],seq:1};
const D={},snap={};
for(const c in COLS){const r=db.prepare('select v from kv where k=?').get(c);D[c]=r?JSON.parse(r.v):structuredClone(COLS[c]);snap[c]=r?r.v:null}
function save(){for(const c in COLS){const s=JSON.stringify(D[c]);if(s!==snap[c]){db.prepare('insert or replace into kv values(?,?)').run(c,s);snap[c]=s}}}
const today=()=>{const d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const nu=s=>String(s||'').trim().toLowerCase(),str=(v,n=200)=>String(v??'').trim().slice(0,n),num=v=>{const x=+v;return Number.isFinite(x)?x:0},sm=a=>a.reduce((s,x)=>s+x.amount,0);
const err=(status,error)=>({status,error});
const hash=(p,s)=>crypto.scryptSync(p,s,32).toString('hex');
function setUser(username,password,role,name){const salt=crypto.randomBytes(8).toString('hex'),u=D.users.find(x=>x.username==username),h=hash(password,salt);
 if(u)Object.assign(u,{salt,hash:h,role,name:name||username});else D.users.push({username,salt,hash:h,role,name:name||username})}
if(!D.users.length){const pw=crypto.randomBytes(5).toString('hex');setUser('admin',pw,'admin','Admin');save();console.log('\n  FIRST RUN - login:  admin  /  '+pw+'\n  Change this password right after logging in.\n')}
const audit=(u,a,d)=>db.prepare('insert into audit(t,u,a,d) values(?,?,?,?)').run(new Date().toISOString(),u,a,d||'');
// backups: daily + every 6h check, keep 14
function backup(){const f=path.join(BK,'school-'+today()+'.db');if(!fs.existsSync(f))db.exec(`VACUUM INTO '${f.replace(/'/g,"''")}'`);
 const all=fs.readdirSync(BK).filter(x=>/^school-.*\.db$/.test(x)).sort();for(const x of all.slice(0,Math.max(0,all.length-14)))fs.unlinkSync(path.join(BK,x))}
backup();setInterval(backup,6*3600e3);
// sessions + login rate limit
const sess=new Map(),fails=new Map(),PERM={fees:['admin','accountant'],att:['admin','teacher'],admin:['admin']};
setInterval(()=>{const n=Date.now();for(const [k,v] of sess)if(v.exp<n)sess.delete(k)},600e3);
const routes={},R=(m,n,perm,fn)=>routes[m+' '+n]={perm,fn};
const act=()=>D.students.filter(s=>s.active),cmp=(a,b)=>String(a.class||'').localeCompare(String(b.class||''),undefined,{numeric:true})||String(a.name).localeCompare(b.name);
const stu=id=>D.students.find(s=>s.id==id)||(()=>{throw err(404,'Not found')})();
// ---- students
R('GET','students','any',()=>act().sort(cmp));
R('POST','students','admin',b=>{const v={name:str(b.name),father:str(b.father),phone:str(b.phone,30),class:str(b.class,30),fee:Math.max(0,num(b.fee)),disc:Math.max(0,num(b.disc)),old:Math.max(0,num(b.old))};if(!v.name)throw err(400,'Name required');
 if(typeof b.photo=='string'&&b.photo.startsWith('data:image/')&&b.photo.length<300000)v.photo=b.photo;
 if(b.id)Object.assign(stu(b.id),v);else D.students.push({id:D.seq++,...v,admitted:today(),active:1});return{ok:1}});
R('POST','students/delete','admin',b=>{stu(b.id).active=0;return{ok:1}});
R('POST','students/import','admin',b=>{let added=0,skipped=0;for(const r of (Array.isArray(b.rows)?b.rows:[]).slice(0,5000)){const name=str(r.name);if(!name)continue;const father=str(r.father),cl=str(r.class,30);
 if(D.students.some(s=>s.active&&s.name==name&&s.father==father&&s.class==cl)){skipped++;continue}
 D.students.push({id:D.seq++,name,father,phone:str(r.phone,30),class:cl,fee:Math.max(0,num(r.fee)),disc:Math.max(0,num(r.disc)),old:Math.max(0,num(r.old)),admitted:today(),active:1});added++}return{added,skipped}});
// ---- fees
const paidOf=(id,m)=>sm(D.payments.filter(x=>x.student_id==id&&x.month==m));
R('GET','fees','fees',(b,q)=>{const m=q.get('month');return act().sort(cmp).map(s=>({...s,paid:paidOf(s.id,m),oldpaid:paidOf(s.id,'old')}))});
R('POST','pay','fees',(b,me)=>{const a=num(b.amount);if(!(a>0))throw err(400,'Invalid amount');if(!/^(\d{4}-\d{2}|old)$/.test(b.month))throw err(400,'Invalid month');stu(b.student_id);
 const id=D.seq++;D.payments.push({id,student_id:+b.student_id,month:b.month,amount:a,date:today(),by:me.name});return{receipt:id,date:today()}});
R('GET','history','fees',(b,q)=>D.payments.filter(x=>x.student_id==q.get('id')).sort((a,b)=>b.id-a.id));
R('POST','pay/delete','admin',b=>{D.payments=D.payments.filter(x=>x.id!=b.id);return{ok:1}});
R('POST','pay/edit','admin',b=>{if(!(num(b.amount)>0))throw err(400,'Invalid amount');const p=D.payments.find(x=>x.id==b.id);if(!p)throw err(404,'Not found');p.amount=num(b.amount);return{ok:1}});
// ---- attendance
R('GET','attendance','att',(b,q)=>{const d=D.att[q.get('date')]||{};return act().sort(cmp).map(s=>({id:s.id,name:s.name,class:s.class,phone:s.phone,status:d[s.id]||null}))});
R('POST','attendance','att',b=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date))throw err(400,'Invalid date');D.att[b.date]=D.att[b.date]||{};for(const m of b.marks||[])if(['P','A','L'].includes(m.status))D.att[b.date][m.id]=m.status;return{ok:1}});
R('GET','att-report','att',(b,q)=>{const m=q.get('month');return act().sort(cmp).map(s=>{const r={name:s.name,class:s.class,p:0,a:0,l:0};for(const d in D.att)if(d.startsWith(m)){const x=D.att[d][s.id];if(x)r[x.toLowerCase()]++}return r})});
// ---- users / account
R('GET','users','admin',()=>D.users.map(({username,name,role})=>({username,name,role})));
const pwOk=p=>String(p||'').length>=6||(()=>{throw err(400,'Password must be at least 6 characters')})();
R('POST','users','admin',b=>{const u=nu(b.username);if(!/^[a-z0-9._-]{2,30}$/.test(u)||!['admin','teacher','accountant'].includes(b.role))throw err(400,'Username, password and role required');pwOk(b.password);
 const ex=D.users.find(x=>x.username==u);if(ex&&ex.role=='admin'&&b.role!='admin'&&D.users.filter(x=>x.role=='admin').length<2)throw err(400,'At least one admin is required');setUser(u,String(b.password).trim(),b.role,str(b.name,60));return{ok:1}});
R('POST','users/delete','admin',(b,q,me)=>{const u=nu(b.username);if(u==me.u)throw err(400,'You cannot delete yourself');D.users=D.users.filter(x=>x.username!=u);for(const [k,v] of sess)if(v.u==u)sess.delete(k);return{ok:1}});
R('POST','password','any',(b,q,me)=>{const u=D.users.find(x=>x.username==me.u);if(!u||hash(String(b.old||''),u.salt)!==u.hash)throw err(400,'Wrong password');pwOk(b.neu);setUser(u.username,String(b.neu),u.role,u.name);return{ok:1}});
// ---- teachers / accounts
R('GET','teachers','fees',(b,q)=>{const m=q.get('month');return D.teachers.filter(x=>x.active).sort((a,b)=>a.name.localeCompare(b.name)).map(x=>{const f=ty=>sm(D.tpay.filter(y=>y.teacher_id==x.id&&y.month==m&&y.type==ty)),c={P:0,A:0,L:0};
 for(const d in D.tatt)if(d.startsWith(m)){const s=D.tatt[d][x.id];if(s)c[s]++}return{...x,adv:f('advance'),paid:f('salary'),pa:c.P,ab:c.A,lv:c.L}})});
R('POST','teachers','admin',b=>{const v={name:str(b.name),phone:str(b.phone,30),subject:str(b.subject),salary:Math.max(0,num(b.salary))};if(!v.name)throw err(400,'Name required');
 if(b.id){const t=D.teachers.find(x=>x.id==b.id);if(!t)throw err(404,'Not found');Object.assign(t,v)}else D.teachers.push({id:D.seq++,...v,active:1});return{ok:1}});
R('POST','teachers/delete','admin',b=>{const t=D.teachers.find(x=>x.id==b.id);if(t)t.active=0;return{ok:1}});
R('POST','tpay','fees',b=>{if(!(num(b.amount)>0))throw err(400,'Invalid amount');if(!['salary','advance'].includes(b.type))throw err(400,'Invalid type');D.tpay.push({id:D.seq++,teacher_id:+b.teacher_id,month:str(b.month,7),type:b.type,amount:num(b.amount),date:today()});return{ok:1}});
R('GET','exp','fees',(b,q)=>D.exp.filter(x=>x.date.startsWith(q.get('month'))).sort((a,b)=>b.id-a.id));
R('POST','exp','fees',b=>{if(!str(b.title)||!(num(b.amount)>0))throw err(400,'Title and amount required');D.exp.push({id:D.seq++,date:today(),title:str(b.title),amount:num(b.amount)});return{ok:1}});
R('POST','exp/delete','admin',b=>{D.exp=D.exp.filter(x=>x.id!=b.id);return{ok:1}});
R('GET','summary','fees',(b,q)=>{const m=q.get('month');return{fees:sm(D.payments.filter(x=>x.date.startsWith(m))),exp:sm(D.exp.filter(x=>x.date.startsWith(m))),sal:sm(D.tpay.filter(x=>x.date.startsWith(m)))}});
// ---- exams
R('GET','exams','att',()=>D.exams);
R('POST','exams','att',b=>{const subs=String(b.subjects||'').split(/[,،]/).map(s=>s.trim()).filter(Boolean);if(!str(b.name)||!subs.length)throw err(400,'Name and subjects required');D.exams.push({id:D.seq++,name:str(b.name),class:str(b.class,30),subjects:subs.slice(0,20),max:num(b.max)||100});return{ok:1}});
R('POST','exams/delete','admin',b=>{D.exams=D.exams.filter(e=>e.id!=b.id);delete D.marks[b.id];return{ok:1}});
R('GET','marks','att',(b,q)=>{const e=D.exams.find(e=>e.id==q.get('id'));if(!e)throw err(404,'Not found');const mk=D.marks[e.id]||{};
 return{exam:e,rows:act().filter(s=>!e.class||s.class==e.class).sort(cmp).map(s=>({id:s.id,name:s.name,class:s.class,phone:s.phone,m:mk[s.id]||[]}))}});
R('POST','marks','att',b=>{if(!D.exams.some(e=>e.id==b.id))throw err(404,'Not found');D.marks[b.id]=D.marks[b.id]||{};for(const r of b.rows||[])D.marks[b.id][r.id]=(Array.isArray(r.m)?r.m:[]).map(v=>v===null||v===''?null:num(v));return{ok:1}});
// ---- notices, timetable, teacher attendance, settings
R('GET','notices','any',()=>[...D.notices].sort((a,b)=>b.id-a.id));
R('POST','notices','admin',b=>{if(!str(b.title))throw err(400,'Title required');D.notices.push({id:D.seq++,date:today(),title:str(b.title),body:str(b.body,2000)});return{ok:1}});
R('POST','notices/delete','admin',b=>{D.notices=D.notices.filter(x=>x.id!=b.id);return{ok:1}});
R('GET','tt','any',(b,q)=>D.tt.filter(x=>x.class==q.get('class')));
R('POST','tt','admin',b=>{if(!str(b.class)||!str(b.subject))throw err(400,'Class and subject required');D.tt=D.tt.filter(x=>!(x.class==b.class&&x.day==b.day&&x.period==b.period));D.tt.push({id:D.seq++,class:str(b.class,30),day:str(b.day,3),period:num(b.period),subject:str(b.subject),teacher:str(b.teacher)});return{ok:1}});
R('POST','tt/delete','admin',b=>{D.tt=D.tt.filter(x=>x.id!=b.id);return{ok:1}});
R('GET','tatt','admin',(b,q)=>{const d=D.tatt[q.get('date')]||{};return D.teachers.filter(x=>x.active).map(x=>({id:x.id,name:x.name,status:d[x.id]||null}))});
R('POST','tatt','admin',b=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date))throw err(400,'Invalid date');D.tatt[b.date]=D.tatt[b.date]||{};for(const m of b.marks||[])if(['P','A','L'].includes(m.status))D.tatt[b.date][m.id]=m.status;return{ok:1}});
R('GET','settings','any',()=>({school:D.settings.school||'',logo:D.settings.logo||''}));
R('POST','settings','admin',b=>{D.settings.school=str(b.school,100);if(typeof b.logo=='string'&&(b.logo===''||(b.logo.startsWith('data:image/')&&b.logo.length<400000)))D.settings.logo=b.logo;return{ok:1}});
// ---- hifz, donations, library, report
R('GET','hifz','att',(b,q)=>{const id=+q.get('student');return{entries:D.hifz.filter(x=>x.student_id==id).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id).slice(0,30),paras:D.para[id]||[]}});
R('POST','hifz','att',b=>{stu(b.student_id);D.hifz.push({id:D.seq++,student_id:+b.student_id,date:/^\d{4}-\d{2}-\d{2}$/.test(b.date)?b.date:today(),sabaq:str(b.sabaq),sabqi:str(b.sabqi),manzil:str(b.manzil),note:str(b.note)});return{ok:1}});
R('POST','hifz/delete','admin',b=>{D.hifz=D.hifz.filter(x=>x.id!=b.id);return{ok:1}});
R('POST','para','att',b=>{const n=num(b.para);if(n<1||n>30)throw err(400,'Invalid');const a=D.para[b.student_id]=D.para[b.student_id]||[],i=a.indexOf(n);if(i>=0)a.splice(i,1);else a.push(n);return{ok:1}});
R('GET','don','fees',(b,q)=>D.don.filter(x=>x.date.startsWith(q.get('month'))).sort((a,b)=>b.id-a.id));
R('POST','don','fees',b=>{if(!(num(b.amount)>0))throw err(400,'Invalid amount');const id=D.seq++;D.don.push({id,date:today(),donor:str(b.donor),phone:str(b.phone,30),type:['General','Zakat','Sadaqah','Fitra'].includes(b.type)?b.type:'General',amount:num(b.amount)});return{id,date:today()}});
R('POST','don/delete','admin',b=>{D.don=D.don.filter(x=>x.id!=b.id);return{ok:1}});
R('GET','books','att',()=>D.books.map(k=>({...k,out:D.loans.filter(l=>l.book_id==k.id&&!l.back).length})));
R('POST','books','admin',b=>{if(!str(b.title))throw err(400,'Title required');D.books.push({id:D.seq++,title:str(b.title),author:str(b.author),copies:Math.max(1,num(b.copies)||1)});return{ok:1}});
R('POST','books/delete','admin',b=>{D.books=D.books.filter(k=>k.id!=b.id);return{ok:1}});
R('POST','loan','att',b=>{const k=D.books.find(k=>k.id==b.book_id);if(!k)throw err(404,'Not found');stu(b.student_id);if(k.copies-D.loans.filter(l=>l.book_id==k.id&&!l.back).length<1)throw err(400,'No copies available');D.loans.push({id:D.seq++,book_id:k.id,student_id:+b.student_id,out:today(),back:null});return{ok:1}});
R('POST','return','att',b=>{const l=D.loans.find(l=>l.id==b.id);if(l)l.back=today();return{ok:1}});
R('GET','loans','att',()=>D.loans.filter(l=>!l.back).map(l=>({id:l.id,out:l.out,book:(D.books.find(k=>k.id==l.book_id)||{}).title,student:(D.students.find(s=>s.id==l.student_id)||{}).name})));
R('GET','report','fees',(b,q)=>{const s=stu(q.get('id')),m=q.get('month'),c={P:0,A:0,L:0};for(const d in D.att)if(d.startsWith(m)){const x=D.att[d][s.id];if(x)c[x]++}
 const tot=a=>Array.from(a).reduce((z,v)=>z+(+v||0),0);let ex=null;for(const e of [...D.exams].sort((a,b)=>b.id-a.id)){const mk=D.marks[e.id]||{};if(mk[s.id]){const all=Object.values(mk).map(tot).sort((a,b)=>b-a),me=tot(mk[s.id]);ex={name:e.name,pct:Math.round(me*1000/(e.max*e.subjects.length))/10,pos:all.indexOf(me)+1};break}}
 const hs=D.hifz.filter(x=>x.student_id==s.id).sort((a,b)=>b.date.localeCompare(a.date)||b.id-a.id)[0];
 return{s,c,due:Math.max(0,s.fee-(s.disc||0)-paidOf(s.id,m)),old:Math.max(0,(s.old||0)-paidOf(s.id,'old')),ex,paras:(D.para[s.id]||[]).length,sabaq:hs?hs.sabaq:''}});
// ---- admin: audit, backup, restore
R('GET','audit','admin',()=>db.prepare('select t,u,a,d from audit order by id desc limit 200').all());
R('GET','backups','admin',()=>fs.readdirSync(BK).filter(x=>x.endsWith('.db')).sort().reverse().map(n=>({name:n,kb:Math.round(fs.statSync(path.join(BK,n)).size/1024)})));
R('GET','backup','admin',()=>{const o={};for(const c in COLS)if(c!='users')o[c]=D[c];return o});
R('POST','restore','admin',b=>{const x=b.data;if(!x||typeof x!='object'||!Array.isArray(x.students))throw err(400,'Invalid backup file');
 db.exec(`VACUUM INTO '${path.join(BK,'pre-restore-'+Date.now()+'.db').replace(/'/g,"''")}'`);
 for(const c in COLS){if(c=='users'||x[c]===undefined)continue;if(c=='seq'){D.seq=Math.max(1,num(x.seq));continue}if(Array.isArray(COLS[c])!==Array.isArray(x[c])||typeof x[c]!='object')throw err(400,'Invalid backup file');D[c]=x[c]}
 let mx=D.seq;for(const c of Object.keys(COLS))if(Array.isArray(D[c]))for(const r of D[c])if(r&&r.id>=mx)mx=r.id+1;D.seq=mx;return{ok:1}});
// ---- dashboard
const monthKey=o=>{const d=new Date();d.setDate(1);d.setMonth(d.getMonth()-o);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')};
R('GET','dashboard','fees',()=>{const m=monthKey(0),A=act(),eff=s=>Math.max(0,s.fee-(s.disc||0)),dueOf=s=>Math.max(0,eff(s)-paidOf(s.id,m)),oldOf=s=>Math.max(0,(s.old||0)-paidOf(s.id,'old')),at=D.att[today()]||{},ids=new Set(A.map(s=>s.id)),c={P:0,A:0,L:0};
 for(const k in at)if(ids.has(+k)&&c[at[k]]!==undefined)c[at[k]]++;
 const months=[5,4,3,2,1,0].map(o=>{const k=monthKey(o);return{m:k,in:sm(D.payments.filter(x=>x.date.startsWith(k))),out:sm(D.exp.filter(x=>x.date.startsWith(k)))+sm(D.tpay.filter(x=>x.date.startsWith(k)))}});
 const TT=D.teachers.filter(x=>x.active),payable=TT.reduce((a,x)=>a+Math.max(0,x.salary-sm(D.tpay.filter(y=>y.teacher_id==x.id&&y.month==m))),0);
 return{month:m,students:A.length,p:c.P,a:c.A,l:c.L,due:A.reduce((a,s)=>a+dueOf(s),0),oldDue:A.reduce((a,s)=>a+oldOf(s),0),in:months[5].in,out:months[5].out,payable,teachers:TT.length,don:sm(D.don.filter(x=>x.date.startsWith(m))),months,
  top:A.map(s=>({id:s.id,name:s.name,class:s.class,phone:s.phone,due:dueOf(s)+oldOf(s)})).filter(x=>x.due>0).sort((a,b)=>b.due-a.due).slice(0,5)}});
// ---- http
const sendJ=(res,c,o,h={})=>{res.writeHead(c,{'Content-Type':'application/json','Cache-Control':'no-store',...h});res.end(JSON.stringify(o))};
const HDR={'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'"};
const readBody=req=>new Promise((ok,no)=>{let n=0;const a=[];req.on('data',c=>{n+=c.length;if(n>60e6){no(err(413,'Too large'));req.destroy()}else a.push(c)});req.on('end',()=>{try{ok(JSON.parse(Buffer.concat(a).toString()||'{}'))}catch{no(err(400,'Bad request'))}});req.on('error',no)});
http.createServer(async(req,res)=>{
 try{const u=new URL(req.url,'http://x'),p=u.pathname;
  if(!p.startsWith('/api/')){if(req.method!='GET'){res.writeHead(405);return res.end()}
   const F={'/':['index.html','text/html; charset=utf-8'],'/index.html':['index.html','text/html; charset=utf-8'],'/style.css':['style.css','text/css; charset=utf-8'],'/app.js':['app.js','application/javascript; charset=utf-8']}[p];
   if(!F){res.writeHead(404);return res.end('Not found')}res.writeHead(200,{'Content-Type':F[1],'Cache-Control':'no-cache',...HDR});return res.end(fs.readFileSync(path.join(__dirname,'public',F[0])))}
  const name=p.slice(5),m=req.method,ip=req.socket.remoteAddress;
  if(m=='GET'&&name=='public')return sendJ(res,200,{school:D.settings.school||'',logo:D.settings.logo||''});
  if(m=='POST'&&name=='login'){const b=await readBody(req),f=fails.get(ip)||{n:0,until:0};if(f.until>Date.now())throw err(429,'Too many attempts. Try again in a few minutes.');
   const us=D.users.find(x=>x.username==nu(b.username));let good=false;if(us){const a=Buffer.from(hash(String(b.password||'').trim(),us.salt)),c=Buffer.from(us.hash);good=a.length==c.length&&crypto.timingSafeEqual(a,c)}else hash('x','y');
   if(!good){f.n++;if(f.n>=5){f.until=Date.now()+10*60e3;f.n=0}fails.set(ip,f);audit(nu(b.username)||'?','login failed',ip);throw err(401,'Wrong username or password')}
   fails.delete(ip);const t=crypto.randomBytes(24).toString('hex');sess.set(t,{u:us.username,role:us.role,name:us.name,exp:Date.now()+12*3600e3});audit(us.username,'login',ip);return sendJ(res,200,{token:t,role:us.role,name:us.name})}
  const tok=(req.headers.authorization||'').slice(7),me=sess.get(tok);
  if(m=='POST'&&name=='logout'){if(me)audit(me.u,'logout');sess.delete(tok);return sendJ(res,200,{ok:1})}
  const rt=routes[m+' '+name];if(!rt)throw err(404,'Not found');
  if(!me||me.exp<Date.now())throw err(401,'Login required');me.exp=Date.now()+12*3600e3;
  if(rt.perm!='any'&&!PERM[rt.perm].includes(me.role)){audit(me.u,'DENIED',m+' '+name);throw err(403,'Not allowed for your role')}
  const b=m=='GET'?{}:await readBody(req),out=rt.fn(b,u.searchParams,me);
  if(m=='POST'){save();audit(me.u,name,JSON.stringify(b,(k,v)=>['password','neu','old','photo','logo','rows','data','marks'].includes(k)&&typeof v!='number'?'…':v).slice(0,300))}
  const h=name=='backup'?{'Content-Disposition':`attachment; filename="school-backup-${today()}.json"`}:{};sendJ(res,200,out,h);
 }catch(e){if(e&&e.status)return sendJ(res,e.status,{error:e.error});console.error(e);try{load()}catch{}sendJ(res,500,{error:'Server error'})}
}).listen(PORT,'0.0.0.0',()=>console.log('School Portal running on http://localhost:'+PORT));
function load(){for(const c in COLS){const r=db.prepare('select v from kv where k=?').get(c);D[c]=r?JSON.parse(r.v):structuredClone(COLS[c])}}
